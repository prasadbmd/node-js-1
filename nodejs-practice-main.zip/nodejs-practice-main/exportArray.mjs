let array = ["countries", 190, "continents", 7, false, 6.2];

export default array;

import array from "./exportArray.mjs";
